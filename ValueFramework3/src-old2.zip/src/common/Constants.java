package common;

import java.awt.Font;

/**
* This class holds many constants used throughout the code
*
* @author Maarten Jensen
*/
public class Constants {
	
	// Initialize important IDs
	public static int ID_ACTION = 0;

}